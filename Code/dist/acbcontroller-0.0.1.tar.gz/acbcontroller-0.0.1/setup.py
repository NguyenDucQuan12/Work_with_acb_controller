from setuptools import setup

setup(
    name='acbcontroller',
    version='0.0.1',
    description='Thu vien dung de ket noi toi bo dieu khien ACB 004',
    author='Nguyen Duc Quan',
    packages=['uhppoted'],  # Chỉ rõ tên thư mục chứa mã nguồn
    package_dir={'uhppoted': 'Code/uhppoted'},  # Đường dẫn tới thư mục chứa mã nguồn
    include_package_data=True,
    install_requires=[],
)
